class Dictionary:
    """
    Classe che definire i metodi base di un dizionario.
    I metodi sono da implementare nelle classi figlie
    """
    def insert(self, key, elem):
        pass

    def delete(self, key):
        pass

    def search(self, key):
        pass
